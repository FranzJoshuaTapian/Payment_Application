
  
<?php $__env->startSection('content'); ?>
<div class="add">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="text-center">
            <h2>Add New Item</h2>
        </div>
        <div class="text-center">
            <a class="btn btn-outline-light" href="<?php echo e(route('applications.index')); ?>"> Back</a>
        </div>
    </div>
</div>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong>Invalid input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
   
<form action="<?php echo e(route('applications.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  
      <div class="row ">
            <div class="form-group">
                <strong>Name:</strong>
                <input type="text-center" name="name" class="form-control" placeholder="Name">
            </div>
        </div>
        
        <div class="row">
            <div class="form-group">
                <strong>Quantity:</strong>
                    <input type="text-center" name="quantity" class="form-control" placeholder="Quantity">
            </div>
        </div>

        <div class="row">
            <div class="form-group">
                <strong>Detail:</strong>
                <input type="text-center" name="detail" class="form-control" placeholder="Details">
            </div>
        </div>
   
        <div class="text-center">
                <button type="submit" class="btn btn-outline-light">Submit</button>
        </div>
    </div>
   
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('applications.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\payapp\resources\views/applications/create.blade.php ENDPATH**/ ?>