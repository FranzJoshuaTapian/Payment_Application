
 
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="text-center">
            <h2><i class="fas fa-coins"></i></i>Payment Application</h2>
                    <p >List of Pending Payments</p>
            </div>
            <div class="text-center">
                <a class="btn btn-outline-light " href="<?php echo e(route('applications.create')); ?>"> Add New Item</a>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-primary">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div class="border"></div>
    <table class="table table-dark table-striped table-hover ">
            <tr>
                <th >#</th>
                <th>Name</th>
                <th >Details</th>
                <th >Quantity</th>
                <th width="280px" >Action</th>
            </tr>
      
        <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($application->name); ?></td>
            <td><?php echo e($application->detail); ?></td>    
            <td><?php echo e($application->quantity); ?></td> 
            <td>
                <form action="<?php echo e(route('applications.destroy',$application->id)); ?>" method="POST">
       
                    <a href="<?php echo e(route('applications.show', $application->id)); ?>" title="show">
                            <i class="fas fa-eye text-light fa-lg"></i></a>
                     
                    <a href="<?php echo e(route('applications.edit', $application->id)); ?>">
                            <i class="fas fa-edit text-light fa-lg"></i></a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" title="delete" style="border: none; background-color:transparent;">
                            <i class="fas fa-trash fa-lg text-light"></i></button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $applications->links(); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('applications.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\payapp\resources\views/applications/index.blade.php ENDPATH**/ ?>