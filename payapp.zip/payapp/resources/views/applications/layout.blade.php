<!DOCTYPE html>
<html>
<head>
    <title>Payment Application</title>
   
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>


    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js"
        integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous">
    </script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js"integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous">
    </script>
       
    <style>
        .container {
            position: relative;
            width: 100%;
            background-color: #000;
            color: white;
            text-align: center;      
        }
    </style>
   
    <style>
         .footer{
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            background-color: #212529;
            color: white;
            text-align: center;
        }
    </style>

    <style>
         .border{
            position: relative;
            height: 150%;
            border: 2px solid;
            color: white; 
        }
    </style>

</head>
<body>

    <div class="container">
        @yield('content')
    </div>
        <div class="text-center footer">
                <h4>Payment Organizer</h4>
                <h5>+639 663 340 700</h5>
                <h5>Newbies12@gmail.com</h5>
       </div>

</body>
</html>